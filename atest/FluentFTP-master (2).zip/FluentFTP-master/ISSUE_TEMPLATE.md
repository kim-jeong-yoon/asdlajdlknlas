**FTP OS:** Unix / Windows / Embedded

**FTP Server:** Pure-FTPd / DrFTPD / Vsftpd / ProFTPD / Vax / VMS / OpenVMS / Tandem / HP NonStop Guardian / IBM OS400 / AS400 / Windows CE

**Computer OS:** ?

**FluentFTP Version:** ?

<write details about your bug report / feature request here>

**Logs :**

<!---
Please generate logs from FluentFTP and paste them in the marked area below.
See this link for steps :

https://github.com/robinrodricks/FluentFTP/wiki/Logging#how-do-i-trace-ftp-commands-for-debugging
-->

```

<paste logs here>

```